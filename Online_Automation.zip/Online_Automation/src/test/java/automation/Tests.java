package automation;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class Tests {
         WebDriver driver = new ChromeDriver();

    @Test (priority=1)
    public void successfulLogin(){
        driver.manage().window().maximize();
        driver.get("https://the-internet.herokuapp.com/");
        driver.findElement(By.xpath("//*[@id=\"content\"]/ul/li[21]/a")).click();
        driver.findElement(By.id("username")).sendKeys("tomsmith");
        driver.findElement(By.id("password")).sendKeys("SuperSecretPassword!");
        driver.findElement(By.className("radius")).click();
        String expectedResult ="You logged into a secure area!";
        String actualResult= driver.findElement(By.id("flash")).getText();
        assertTrue(actualResult.contains(expectedResult));
    }
    @Test (priority=2)
    public void wrongUsername(){
        driver.get("https://the-internet.herokuapp.com/");
        driver.findElement(By.xpath("//*[@id=\"content\"]/ul/li[21]/a")).click();
        driver.findElement(By.id("username")).sendKeys("wrongUsername");
        driver.findElement(By.id("password")).sendKeys("SuperSecretPassword!");
        driver.findElement(By.className("radius")).click();
        String expectedResult ="Your username is invalid!";
        String actualResult= driver.findElement(By.id("flash")).getText();
        assertTrue(actualResult.contains(expectedResult));
    }

@Test (priority=3)
public void wrongPassword(){
    driver.get("https://the-internet.herokuapp.com/");
    driver.findElement(By.xpath("//*[@id=\"content\"]/ul/li[21]/a")).click();
    driver.findElement(By.id("username")).sendKeys("tomsmith");
    driver.findElement(By.id("password")).sendKeys("wrongpassword");
    driver.findElement(By.className("radius")).click();
    String expectedResult ="Your password is invalid!";
    String actualResult= driver.findElement(By.id("flash")).getText();
    assertTrue(actualResult.contains(expectedResult));
    driver.quit();
}
}
